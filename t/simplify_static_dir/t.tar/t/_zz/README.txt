File links used to control file system side effects
